from train import *


trainingfunction()